zipをダウンロードして解凍後、
MyGame.exe を起動してください。
ウィンドウサイズは縦80横30より大きくしましょう。


After downloading and extracting the zip file,
please launch MyGame.exe. 
Make the window size larger than 80 vertical by 30 horizontal.